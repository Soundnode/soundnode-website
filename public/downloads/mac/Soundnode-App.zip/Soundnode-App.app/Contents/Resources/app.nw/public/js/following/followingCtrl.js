'use strict';

app.controller('FollowingCtrl', function ($scope, $http) {
    $scope.title = 'Following view';
});