"use strict";

// Initialize modules
authentication.init();
userConfig.windowState();
userConfig.scaleInit();
guiConfig.init();
