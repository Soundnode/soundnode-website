// Set up some core settings
window.settings = window.settings || {};

// App version
window.settings.appVersion = '0.5.2';